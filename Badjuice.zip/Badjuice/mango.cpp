#include "mango.h"

mango::mango()
{

}
