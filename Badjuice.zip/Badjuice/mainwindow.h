#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QKeyEvent>
#include <QTimer>
#include <QList>
#include "cuchillo.h"
#include "animales.h"
#include "frutas.h"
#include "rata.h"


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void keyPressEvent(QKeyEvent *event);
public slots:
    void poscuchillo(void);
    void posFrutas(void);
    void CrearFruta(void);

private:
    Ui::MainWindow *ui;
    QGraphicsScene *scene;
    QGraphicsView *view;
    cuchillo *hoja;
    rata *rata1;


    QList<frutas *> listafruta;
    QList<frutas *>::iterator i;
    QList<frutas *>::iterator j;
    QList<frutas *>frutascolisionadas;

    QTimer *tiempocuhillo;
    QTimer *tiempoFrutas;
    QTimer *tiempoCrear;


};
#endif // MAINWINDOW_H
