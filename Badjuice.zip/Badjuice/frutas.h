#ifndef FRUTAS_H
#define FRUTAS_H


class frutas
{
public:
    frutas();
};

#endif // FRUTAS_H
