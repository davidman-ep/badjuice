#ifndef FRUTAS_H
#define FRUTAS_H
#include <QGraphicsItem>
#include <QPainter>
#include <QRandomGenerator>


class frutas:public QGraphicsItem
{
    qreal x,y;
    qreal vx,vy;



public:
    frutas();

    virtual QRectF boundingRect() const;
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr);
    void curvaMov(void);
    qreal getBottomY() const;
    qreal getVy() const;
    void setVy(qreal newVy);
    qreal getAx() const;
    void setAx(qreal newAx);
    qreal getX() const;
    void setX(qreal newX);
    qreal getY() const;
    void setY(qreal newY);
};

#endif // FRUTAS_H
