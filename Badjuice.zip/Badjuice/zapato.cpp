#include "zapato.h"

zapato::zapato()
{

}
