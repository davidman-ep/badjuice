#ifndef BANANO_H
#define BANANO_H


class banano
{
public:
    banano();
};

#endif // BANANO_H
