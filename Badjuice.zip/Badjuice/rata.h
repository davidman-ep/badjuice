#ifndef RATA_H
#define RATA_H
#include "animales.h"


class rata:public animales
{
public:
    rata();
    virtual QRectF boundingRect() const;
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr);

    void movimiento(void);
};

#endif // RATA_H
