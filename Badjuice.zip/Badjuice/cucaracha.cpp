#include "cucaracha.h"

cucaracha::cucaracha()
{

}
