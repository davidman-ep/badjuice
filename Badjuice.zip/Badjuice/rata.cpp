#include "rata.h"


rata::rata()
{
    this->x=150;
    this->y=150;
    this->ang=0;
}
QRectF rata::boundingRect() const
{
    return QRectF(x,y,50,50);
}
void rata::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setBrush(Qt::gray);
    painter->setPen(Qt::darkGray);
    painter->drawEllipse(boundingRect());
    Q_UNUSED(option);
    Q_UNUSED(widget);
}
void rata::movimiento()
{
    qreal Cx=100;
    qreal Cy=100;
    qreal delta=0.1;
    //ecuaciones parametricas de elipse
    //x=Cx+40*qCos(ang);
    //y=Cy+40*qSin(ang);
    x=Cx+60*qCos(3*ang)*qCos(ang);
    y=Cy+60*qCos(3*ang)*qSin(ang);
    ang+=delta;
    setPos(x,y);
}
