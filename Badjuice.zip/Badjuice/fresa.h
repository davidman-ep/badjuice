#ifndef FRESA_H
#define FRESA_H


class fresa
{
public:
    fresa();
};

#endif // FRESA_H
