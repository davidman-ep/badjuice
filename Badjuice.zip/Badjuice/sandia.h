#ifndef SANDIA_H
#define SANDIA_H


class sandia
{
public:
    sandia();
};

#endif // SANDIA_H
