#ifndef MORA_H
#define MORA_H


class mora
{
public:
    mora();
};

#endif // MORA_H
