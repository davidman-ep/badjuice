#include "fresa.h"

fresa::fresa()
{

}
