#ifndef GUSANO_H
#define GUSANO_H


class gusano
{
public:
    gusano();
};

#endif // GUSANO_H
