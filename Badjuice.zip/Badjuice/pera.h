#ifndef PERA_H
#define PERA_H


class pera
{
public:
    pera();
};

#endif // PERA_H
