#include "aranha.h"

aranha::aranha()
{

}
