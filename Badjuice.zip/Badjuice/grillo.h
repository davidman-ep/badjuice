#ifndef GRILLO_H
#define GRILLO_H


class grillo
{
public:
    grillo();
};

#endif // GRILLO_H
