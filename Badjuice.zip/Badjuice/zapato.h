#ifndef ZAPATO_H
#define ZAPATO_H


class zapato
{
public:
    zapato();
};

#endif // ZAPATO_H
