#ifndef LATA_H
#define LATA_H


class lata
{
public:
    lata();
};

#endif // LATA_H
