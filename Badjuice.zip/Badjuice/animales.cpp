#include "animales.h"

animales::animales()
{
    this->x=150;
    this->y=150;
    this->ang=0;
}


QRectF animales::boundingRect() const
{
    return QRectF(x,y,50,50);
}
void animales::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setBrush(Qt::gray);
    painter->setPen(Qt::darkGray);
    painter->drawEllipse(boundingRect());
    Q_UNUSED(option);
    Q_UNUSED(widget);
}
