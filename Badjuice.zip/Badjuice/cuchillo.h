#ifndef CUCHILLO_H
#define CUCHILLO_H


class cuchillo
{
public:
    cuchillo();
};

#endif // CUCHILLO_H
