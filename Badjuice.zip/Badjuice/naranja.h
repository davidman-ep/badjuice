#ifndef NARANJA_H
#define NARANJA_H


class naranja
{
public:
    naranja();
};

#endif // NARANJA_H
