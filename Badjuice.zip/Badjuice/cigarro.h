#ifndef CIGARRO_H
#define CIGARRO_H


class cigarro
{
public:
    cigarro();
};

#endif // CIGARRO_H
