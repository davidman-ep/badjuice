#include "mora.h"

mora::mora()
{

}
