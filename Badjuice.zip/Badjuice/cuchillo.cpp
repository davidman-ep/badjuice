#include "cuchillo.h"

cuchillo::cuchillo()
{

}
