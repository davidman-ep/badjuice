#include "sandia.h"

sandia::sandia()
{

}
