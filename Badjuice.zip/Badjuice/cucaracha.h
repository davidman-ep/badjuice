#ifndef CUCARACHA_H
#define CUCARACHA_H


class cucaracha
{
public:
    cucaracha();
};

#endif // CUCARACHA_H
