#ifndef MANZANA_H
#define MANZANA_H


class manzana
{
public:
    manzana();
};

#endif // MANZANA_H
