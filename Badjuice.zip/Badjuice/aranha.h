#ifndef ARANHA_H
#define ARANHA_H


class aranha
{
public:
    aranha();
};

#endif // ARANHA_H
