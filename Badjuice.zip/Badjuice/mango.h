#ifndef MANGO_H
#define MANGO_H


class mango
{
public:
    mango();
};

#endif // MANGO_H
