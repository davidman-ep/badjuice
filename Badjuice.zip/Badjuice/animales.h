#ifndef ANIMALES_H
#define ANIMALES_H


class animales
{
public:
    animales();
};

#endif // ANIMALES_H
