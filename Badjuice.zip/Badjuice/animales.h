#ifndef ANIMALES_H
#define ANIMALES_H
#include <QGraphicsItem>
#include <qmath.h>
#include <QPainter>

class animales:public QGraphicsItem
{
public:
    qreal x,y,vx,vy,ang,radio,masa;

public:
    animales();
    virtual QRectF boundingRect() const;
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr);

};

#endif // ANIMALES_H
