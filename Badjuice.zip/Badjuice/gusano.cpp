#include "gusano.h"

gusano::gusano()
{

}
