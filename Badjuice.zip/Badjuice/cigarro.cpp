#include "cigarro.h"

cigarro::cigarro()
{

}
