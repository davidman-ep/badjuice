#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Badjuice");
    scene=new QGraphicsScene(this);//escena
    view=new QGraphicsView;//escenario
    hoja= new cuchillo;
    rata1=new rata;
    //ani1=new animales;
    QPixmap fondo(":/recursos/fondomadera.png");

    tiempocuhillo=new QTimer();
    tiempoFrutas=new QTimer();
    tiempoCrear=new QTimer();
    tiempocuhillo->start(30);
    tiempoFrutas->start(30);
    tiempoCrear->start(1500);

    scene->setSceneRect(0,0,730,570);
    ui->graphicsView->setBackgroundBrush(fondo.scaled(730,560,Qt::IgnoreAspectRatio,Qt::FastTransformation));
    ui->graphicsView->setCacheMode(QGraphicsView::CacheBackground);
    ui->graphicsView->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
    ui->graphicsView->setDragMode(QGraphicsView::ScrollHandDrag);

    //scene->addItem(ani1);
    scene->addItem(rata1);
    scene->addItem(hoja);

    connect(tiempocuhillo,&QTimer::timeout,this,&MainWindow::poscuchillo);
    connect(tiempoFrutas,&QTimer::timeout,this,&MainWindow::posFrutas);
    connect(tiempoCrear,&QTimer::timeout,this,&MainWindow::CrearFruta);

    ui->graphicsView->setScene(scene);
}
void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_A){
        hoja->setVx(-20);

    }else if (event->key() == Qt::Key_S) {
        hoja->setVy(20);

    }else if (event->key() == Qt::Key_D) {
        hoja->setVx(20);

    }else if(event->key() == Qt::Key_W) {
        hoja->setVy(-20);
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::poscuchillo()
{
    hoja->actualizar();
    //ani1->movimiento();
    rata1->movimiento();
    //***********************
    j=listafruta.begin();
    for(auto item:qAsConst(listafruta)){
        item->curvaMov();
    }
    //*************************+
    for (auto fruta : qAsConst(listafruta)) {
            if (fruta->collidesWithItem(hoja, Qt::IntersectsItemBoundingRect)) {
                frutascolisionadas.append(fruta);
            }
        }
    for (auto fruta : qAsConst(frutascolisionadas)) {
           scene->removeItem(fruta);
           listafruta.removeOne(fruta);
           //delete fruta;
       }
    //*************************+
//    i = listafruta.begin();
//       while (i != listafruta.end()) {
//           frutas* fruta = *i;
//           fruta->curvaMov();

//           if (fruta->getBottomY() >= 240) {
//               scene->removeItem(fruta);
//               delete fruta;
//               i = listafruta.erase(i);
//           } else {
//               ++i;
//           }
//       }

//    j=listafruta.begin();
//    for(auto item:qAsConst(listafruta)){
//        item->curvaMov();
//        j++;
//    }
//    for (int i = listafruta.size() - 1; i >= 0; --i) {
//        frutas* fruta = listafruta.at(i);
//        if (hoja->collidesWithItem(fruta, Qt::IntersectsItemBoundingRect)) {
//            frutascolisionadas.append(fruta);
//        }
//    }

//    for (frutas* fruta : qAsConst(frutascolisionadas)) {
//        scene->removeItem(fruta);
//        listafruta.removeOne(fruta);
//        delete fruta;
//    }


//    i=listafruta.begin();
//    for(auto item:qAsConst(listafruta)){
//        if(item->collidesWithItem(hoja,Qt::IntersectsItemBoundingRect)){
//            scene->removeItem(item);
//            listafruta.erase(i);
//            delete item;
//        }
//        else{
//           i++;
//        }

//    }

}

void MainWindow::posFrutas()
{



//    for(auto fruta: qAsConst(listafruta)){
//        fruta->curvaMov();
//        if(fruta->getY()>=280){
//            frutascolisionadas.append(fruta);
//        }
//    }
//    for (auto fruta : qAsConst(frutascolisionadas)) {
//            listafruta.removeOne(fruta);
//            scene->removeItem(fruta);
////            delete fruta;
//        }

}

void MainWindow::CrearFruta()
{
    listafruta.push_back(new frutas);
    scene->addItem(listafruta.back());
}

