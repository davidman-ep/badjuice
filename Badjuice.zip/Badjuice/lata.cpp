#include "lata.h"

lata::lata()
{

}
